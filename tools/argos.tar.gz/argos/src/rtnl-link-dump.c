/* This example is placed in the public domain. */
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include <arpa/inet.h>

//#include <libmnl.h>
#include <libmnl/libmnl.h>
#include <linux/inet_diag.h>
#include <linux/sock_diag.h>
#include <linux/tcp.h>


enum {
    TCP_ESTABLISHED = 1,
    TCP_SYN_SENT,
    TCP_SYN_RECV,
    TCP_FIN_WAIT1,
    TCP_FIN_WAIT2,
    TCP_TIME_WAIT, // 6
    TCP_CLOSE,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
    TCP_LISTEN, // 10
    TCP_CLOSING,    /* Now a valid state */
    TCP_NEW_SYN_RECV,

    TCP_MAX_STATES  /* Leave at the end! */
};

static int
inet_diag_msg_type(struct nlattr const *nlattr, void *data) {
    if (mnl_attr_get_type(nlattr) != INET_DIAG_INFO)
        return MNL_CB_OK;

    const struct tcp_info **tcpi = data;
    *tcpi = mnl_attr_get_payload(nlattr);
    return MNL_CB_OK;
}

static int
inet_diag_parse(struct nlmsghdr const *nlh, void *data){
    struct inet_diag_msg *msg = mnl_nlmsg_get_payload(nlh);
    char src[17] = {0};
    char dst[17] = {0};

    inet_ntop(AF_INET, (void const*)msg->id.idiag_src, src, 16);
    inet_ntop(AF_INET, (void const*)msg->id.idiag_dst, dst, 16);

    printf("%s -> %s: %d\n", src, dst, msg->idiag_state);

    struct tcp_info *tcpi = 0;
    mnl_attr_parse(nlh, sizeof(struct inet_diag_msg), inet_diag_msg_type, &tcpi);

    if (tcpi)
        printf("   %llu - %llu \n", tcpi->tcpi_bytes_acked, tcpi->tcpi_bytes_received);

    return MNL_CB_OK;
}

int main(void)
{
	int ret;
	unsigned int seq, portid;

    struct mnl_socket *nl;
	struct nlmsghdr *nlh;
    struct inet_diag_req_v2* conn_req;

	char buf[MNL_SOCKET_BUFFER_SIZE];

	nlh = mnl_nlmsg_put_header(buf);
	nlh->nlmsg_type	= SOCK_DIAG_BY_FAMILY; //RTM_GETLINK;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
	nlh->nlmsg_seq = seq = time(NULL);

    conn_req = mnl_nlmsg_put_extra_header(nlh, sizeof(struct inet_diag_req_v2));
    conn_req->idiag_ext = (1 << (INET_DIAG_INFO -1));
    conn_req->sdiag_family = AF_INET;
    conn_req->sdiag_protocol = IPPROTO_TCP;

    //Filter->out some states, to show how it is done
    conn_req->idiag_states = 0xfff;
    //TCPF_ALL; /*& 

	nl = mnl_socket_open(NETLINK_INET_DIAG);
	if (nl == NULL) {
		perror("mnl_socket_open");
		exit(EXIT_FAILURE);
	}

	if (mnl_socket_bind(nl, 0, MNL_SOCKET_AUTOPID) < 0) {
		perror("mnl_socket_bind");
		exit(EXIT_FAILURE);
	}
	portid = mnl_socket_get_portid(nl);

	if (mnl_socket_sendto(nl, nlh, nlh->nlmsg_len) < 0) {
		perror("mnl_socket_sendto");
		exit(EXIT_FAILURE);
	}

	ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
	while (ret > 0) {
		ret = mnl_cb_run(buf, ret, seq, portid, inet_diag_parse, NULL);
		if (ret <= MNL_CB_STOP)
			break;
		ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
	}

	if (ret == -1) {
		perror("error");
		exit(EXIT_FAILURE);
	}

	mnl_socket_close(nl);

	return 0;
}
